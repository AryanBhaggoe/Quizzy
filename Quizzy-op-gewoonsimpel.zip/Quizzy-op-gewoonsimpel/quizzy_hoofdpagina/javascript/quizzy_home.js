function scrollTo1() {

    let section3 = document.getElementById('section-3')
    window.scrollTo({
        top: section3.offsetTop,
        behavior: 'smooth'
    });

}
function scrollTo2() {

    let section3 = document.getElementById('section-3')
    window.scrollTo({
        top: section3.offsetTop,
        behavior: 'smooth'
    });

}